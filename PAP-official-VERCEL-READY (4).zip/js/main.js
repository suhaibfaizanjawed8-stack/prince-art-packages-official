/* Shared site behaviors. Contact form creates a draft in your own email app. */
'use strict';
const CONTACT_EMAIL = 'REPLACE_WITH_YOUR_EMAIL'; // e.g. sales@yourdomain.com — REQUIRED before form goes live.
(function(){
 const menu=document.querySelector('.nav-toggle'), nav=document.querySelector('.site-nav');
 if(menu&&nav){
   menu.addEventListener('click',()=>{const active=menu.getAttribute('aria-expanded')==='true';menu.setAttribute('aria-expanded',String(!active));nav.classList.toggle('open',!active);});
   nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menu.setAttribute('aria-expanded','false');}));
   document.addEventListener('keydown',e=>{if(e.key==='Escape'){nav.classList.remove('open');menu.setAttribute('aria-expanded','false');}});
 }
 document.querySelectorAll('[data-year]').forEach(el=>{el.textContent=new Date().getFullYear();});
 const filters=[...document.querySelectorAll('[data-filter]')];
 if(filters.length){
  const products=[...document.querySelectorAll('[data-category]')];
  filters.forEach(button=>button.addEventListener('click',()=>{
   const filter=button.dataset.filter;
   filters.forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
   products.forEach(card=>{card.hidden=!(filter==='all'||card.dataset.category===filter);});
  }));
 }
 const form=document.querySelector('#inquiry-form');
 if(form){
  const status=document.querySelector('#form-status');
  form.addEventListener('submit',function(e){
   e.preventDefault();
   if(!form.reportValidity())return;
   if(!CONTACT_EMAIL.includes('@')||CONTACT_EMAIL.includes('REPLACE_')){
    status.textContent='The website owner must set CONTACT_EMAIL in js/main.js before this form can send inquiries.';
    status.className='form-status error';status.hidden=false;return;
   }
   const data=new FormData(form);
   const body=['Name: '+data.get('name'),'Email: '+data.get('email'),'Company: '+data.get('company'),'Interested in: '+data.get('interest'),'Message: '+data.get('message')].join('\n');
   const subject='Packaging inquiry from '+data.get('name');
   const url='mailto:'+encodeURIComponent(CONTACT_EMAIL)+'?subject='+encodeURIComponent(subject)+'&body='+encodeURIComponent(body);
   status.textContent='Your email application will open with a draft. Please press Send there to submit your inquiry.';
   status.className='form-status success';status.hidden=false;
   window.location.href=url;
  });
 }
})();
